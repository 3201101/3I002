package pobj.partiel2014nov;

import java.util.List;

public class Question5
{
	/**
	 * Construit un dictionnaire d'exemple basé sur la figure 2 de l'énoncé
	 * @return Dictionnaire construit
	 */
	public static Dico creerDico()
	{
		Dico d = new Dico();

		d.ajoute("FA");
		d.ajoute("FAR");
		d.ajoute("FAUX");
		d.ajoute("FRISE");
		d.ajoute("FRIT");
		d.ajoute("FRITE");

		return d;
	}
}
