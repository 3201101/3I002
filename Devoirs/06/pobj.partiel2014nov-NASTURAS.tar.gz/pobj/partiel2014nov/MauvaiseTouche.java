package pobj.partiel2014nov;

public class MauvaiseTouche extends Exception {

}
