package pobj.partiel2014nov.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestQuestion1.class,
	TestQuestion2.class,
	TestQuestion3.class,
	TestQuestion4.class,
	TestQuestion5.class,
	TestQuestion6.class,
	TestQuestion7.class,
	TestQuestion8.class,
	TestQuestion9.class
})
public class TestSuite {

}
