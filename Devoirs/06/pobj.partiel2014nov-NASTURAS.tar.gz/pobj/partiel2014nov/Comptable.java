package pobj.partiel2014nov;

public interface Comptable {
	/**
	 * @return le nombre de noeuds total dans la représentation
	 */
    int nombreNoeud();
	/**
	 * @return le nombre total de mots stockés 
	 */    
    int nombreMot();
}
